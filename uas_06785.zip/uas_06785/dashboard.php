<?php
require_once 'config.php';
requireLogin();

$success = '';
$error = '';

// Proses hapus pegawai
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    
    // Ambil nama foto untuk dihapus
    $query = "SELECT foto FROM pegawai WHERE id = $id";
    $result = mysqli_query($conn, $query);
    if ($result && $row = mysqli_fetch_assoc($result)) {
        if ($row['foto'] && file_exists('uploads/' . $row['foto'])) {
            unlink('uploads/' . $row['foto']);
        }
    }
    
    $query = "DELETE FROM pegawai WHERE id = $id";
    if (mysqli_query($conn, $query)) {
        $success = "Data pegawai berhasil dihapus!";
    }
}

// Ambil pesan success dari URL
if (isset($_GET['success'])) {
    $success = htmlspecialchars($_GET['success']);
}

// Ambil data pegawai
$query = "SELECT * FROM pegawai ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
$total_pegawai = mysqli_num_rows($result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Pegawai</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
        }
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .navbar h1 {
            font-size: 24px;
        }
        .navbar .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 20px;
            border: 1px solid white;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
        }
        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .stat-icon {
            font-size: 48px;
        }
        .stat-info h3 {
            color: #999;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 5px;
        }
        .stat-info p {
            font-size: 32px;
            font-weight: 700;
            color: #333;
        }
        .card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .card-header h2 {
            color: #333;
            font-size: 22px;
        }
        .btn-tambah {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
            transition: transform 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-tambah:hover {
            transform: translateY(-2px);
        }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 15px 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .foto-preview {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #eee;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        .btn-edit {
            background: #28a745;
            color: white;
            padding: 6px 14px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 13px;
            display: inline-block;
        }
        .btn-edit:hover {
            background: #218838;
        }
        .btn-hapus {
            background: #dc3545;
            color: white;
            padding: 6px 14px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 13px;
            display: inline-block;
        }
        .btn-hapus:hover {
            background: #c82333;
        }
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        .no-data-icon {
            font-size: 64px;
            margin-bottom: 15px;
        }
        .no-data p {
            font-size: 16px;
            margin-bottom: 20px;
        }
        @media (max-width: 768px) {
            table {
                font-size: 14px;
            }
            th, td {
                padding: 10px 8px;
            }
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>📊 Dashboard Sistem Pegawai</h1>
        <div class="user-info">
            <span>👤 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <!-- Statistik -->
        <div class="stats">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-info">
                    <h3>Total Pegawai</h3>
                    <p><?php echo $total_pegawai; ?></p>
                </div>
            </div>
        </div>
        
        <!-- Daftar Pegawai -->
        <div class="card">
            <div class="card-header">
                <h2>📋 Daftar Pegawai</h2>
                <a href="tambah_pegawai.php" class="btn-tambah">
                    <span>➕</span>
                    <span>Tambah Data</span>
                </a>
            </div>
            
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Foto</th>
                            <th>NIP</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Tanggal Dibuat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <?php if ($row['foto']): ?>
                                        <img src="uploads/<?php echo htmlspecialchars($row['foto']); ?>" 
                                             class="foto-preview" 
                                             alt="Foto <?php echo htmlspecialchars($row['nama']); ?>">
                                    <?php else: ?>
                                        <span style="font-size: 30px;">📷</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['nip']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="edit_pegawai.php?id=<?php echo $row['id']; ?>" class="btn-edit">
                                            ✏️ Edit
                                        </a>
                                        <a href="?hapus=<?php echo $row['id']; ?>" 
                                           class="btn-hapus" 
                                           onclick="return confirm('Yakin ingin menghapus data ini?')">
                                            🗑️ Hapus
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <div class="no-data-icon">📭</div>
                    <p>Belum ada data pegawai.</p>
                    <a href="tambah_pegawai.php" class="btn-tambah">
                        <span>➕</span>
                        <span>Tambah Data Pertama</span>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>